
document.querySelector("form").addEventListener("submit", function(event) {
    event.preventDefault();
    alert("Your booking has been confirmed!");
});
